extends BaseStageScene3D

onready var animationTree = $AnimationTree
onready var doll = $Doll3D
onready var flipper = $"%Flipper"
onready var chair = $"%Chair"

func _init():
	id = "MyStage"

func _ready():
	animationTree.active = true
	
func updateSubAnims():
	if(doll.getArmsCuffed()):
		animationTree["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree["parameters/CuffsBlend/blend_amount"] = 0.0

func playAnimation(animID, _args = {}):
	print("Playing: "+str(animID))
	if(_args.has("pc")):
		doll.prepareCharacter(_args["pc"])
	else:
		doll.prepareCharacter("pc")

	if(_args.has("bodyState")):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})
	
	updateSubAnims()
	
	if(_args.has("pcCum") && _args["pcCum"]):
		startCumPenis(doll)
		
	var state_machine = animationTree["parameters/AnimationNodeStateMachine/playback"]

	if(animID == "hover"):
		state_machine.travel("Hover-loop")
	elif(animID == "fly"):
		state_machine.travel("Fly")
	else:
		Log.printerr("Action "+str(animID)+" is not found for stage "+str(id))

func getSupportedStates():
	return ["hover", "fly"]

func canTransitionTo(_actionID, _args = []):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
		
	if(doll.getCharacterID() != firstDoll):
		return false
	return true

func getVarNpcs():
	return ["pc"]
