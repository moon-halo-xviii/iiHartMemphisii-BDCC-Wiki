extends Module

func _init():
	id = "MyModule"
	author = "Me"

	stageScenes = [
		"res://Modules/MyModule/Player/StageScene3D/MyStage.tscn",
	]
