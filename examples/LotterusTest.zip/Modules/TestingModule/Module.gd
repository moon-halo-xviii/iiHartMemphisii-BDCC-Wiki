extends Module

func _init():
	id = "TestingModule"
	author = "Lottery"
	
	stageScenes = [
		"res://Modules/TestingModule/Player/StageScene3D/Scenes/Balance.tscn",
	]
