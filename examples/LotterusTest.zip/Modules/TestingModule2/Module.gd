extends Module

func _init():
	id = "TestingModule2"
	author = "Lottery"
	
	stageScenes = [
		"res://Modules/TestingModule2/Player/StageScene3D/Scenes/TrapShit.tscn",
	]
