extends BaseStageScene3D

onready var animationTree = $AnimationTree
onready var animationTree2 = $AnimationTree2
onready var doll = $Doll3D
onready var doll2 = $Doll3D2

func _init():
	id = "TrapShitStage"

func _ready():
	animationTree.anim_player = animationTree.get_path_to(doll.getAnimPlayer())
	animationTree.active = true
	animationTree2.anim_player = animationTree2.get_path_to(doll2.getAnimPlayer())
	animationTree2.active = true

func stateMachineTravel(_thedoll, state_machine, animID):
	var _args = []
	if(animID is Array):
		_args = animID
		animID = animID[0]
	
	#thedoll.attachTemporaryUnriggedPart("hand.R", "res://Inventory/UnriggedModels/BigWrench/BigWrench.tscn")
	if(animID == ""):
		pass
	elif(animID == "shoggers"):
		state_machine.travel("Shoggers-loop")
	elif(animID == "defeat"):
		state_machine.travel("Defeat")
	else:
		return false
	return true

func updateSubAnims():
	if(doll.getArmsCuffed()):
		animationTree["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree["parameters/CuffsBlend/blend_amount"] = 0.0
	
	if(doll2.getArmsCuffed()):
		animationTree2["parameters/CuffsBlend/blend_amount"] = 1.0
	else:
		animationTree2["parameters/CuffsBlend/blend_amount"] = 0.0

# StageScene.Duo, "kneel", {npc="nova", pc="pc"}
func playAnimation(animID, _args = {}):
	var fullAnimID = animID
	if(animID is Array):
		animID = animID[0]
	
	print("Playing duo: "+str(animID))
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	doll.prepareCharacter(firstDoll)
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
	doll2.prepareCharacter(secondDoll)
	
	#doll.forceSlotToBeVisible(BodypartSlot.Penis)
	
	if(_args.has("bodyState")):
		doll.applyBodyState(_args["bodyState"])
	else:
		doll.applyBodyState({})
	
	if(_args.has("npcBodyState")):
		doll2.applyBodyState(_args["npcBodyState"])
	else:
		doll2.applyBodyState({})
		
	if(_args.has("flipNPC") && _args["flipNPC"]):
		doll2.scale.x = abs(doll2.scale.x)
	else:
		doll2.scale.x = -abs(doll2.scale.x)
	
	updateSubAnims()
	
	if(_args.has("pcCum") && _args["pcCum"]):
		startCumPenis(doll)
	if(_args.has("npcCum") && _args["npcCum"]):
		startCumPenis(doll2)
	
	var state_machine = animationTree["parameters/AnimationNodeStateMachine/playback"]
	if(!stateMachineTravel(doll, state_machine, fullAnimID)):
		Log.printerr("Action "+str(animID)+" is not found for stage "+str(id))
	
	if(_args.has("npcAction")):
		var npcAnimID = _args["npcAction"]
		var fullNpcAnimID = npcAnimID
		if(npcAnimID is Array):
			npcAnimID = npcAnimID[0]
		
		var state_machine2 = animationTree2["parameters/AnimationNodeStateMachine/playback"]
		if(!stateMachineTravel(doll2, state_machine2, fullNpcAnimID)):
			Log.printerr("Action "+str(animID)+" is not found for stage "+str(id))
	else:
		var state_machine2 = animationTree2["parameters/AnimationNodeStateMachine/playback"]
		stateMachineTravel(doll2, state_machine2, "Balance")

func canTransitionTo(_actionID, _args = []):
	var firstDoll = "pc"
	if(_args.has("pc")):
		firstDoll = _args["pc"]
	var secondDoll = "pc"
	if(_args.has("npc")):
		secondDoll = _args["npc"]
		
	if(doll.getCharacterID() != firstDoll || doll2.getCharacterID() != secondDoll):
		return false
	return true

func getSupportedStates():
	return ["getshot", "defeat", "shoggers"]

func getChainPoint(_pointID):
	if(_pointID == "farleft"):
		return $FarLeft
	if(_pointID == "farright"):
		return $FarRight
	if(_pointID == "above"):
		return $Above
	if(_pointID == "floor"):
		return $Floor
	return .getChainPoint(_pointID)

func getVarNpcs():
	return ["pc", "npc"]

func getVarOptions():
	var options = .getVarOptions()
	
	options["flipNPC"] = {
		type = "bool",
	}
	options["further"] = {
		type = "bool",
	}
	options["npcAction"] = {
		type = "action",
		actions = getSupportedStates(),
	}
	
	return options
